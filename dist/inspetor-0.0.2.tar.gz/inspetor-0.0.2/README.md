<p>
  <img src="https://github.com/inspetor/slate/blob/master/source/images/logo-color.png" width="200" height="40" alt="Inspetor Logo">
</p>

# Inspetor Antifraud
Antrifraud Inspetor library for Python.

## Description
Inspetor is an product developed to help your company to avoid fraudulent transactions.